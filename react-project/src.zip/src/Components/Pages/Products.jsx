// import axios from "axios"

// function Products() {
//     axios.get(`http://localhost:${process.env.REACT_APP_JSON_SERVER_PORT}/products`)
//         .then((res) => {
//             console.log(res.data)
//         })
//         .catch((err) => {
//             console.log(err)
//         })
// }
// export default Products;
